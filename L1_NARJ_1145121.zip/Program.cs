﻿using System;

namespace L1_NARJ_1145121
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese su nombre: ");
            String Nombre = Console.ReadLine();

            Console.WriteLine(" Hola Mundo ");
            Console.WriteLine(" Soy " + Nombre);
            
            Console.Write(" Hola Mundo ");
            Console.Write("Soy " + Nombre);

            Console.ReadKey(); 
        }
    }
}
